const defaultAvatar =
  "https://img.freepik.com/premium-vector/online-shop-logo-designs-concept-vector-online-store-logo-designs_7649-661.jpg?w=2000";

export { defaultAvatar };
