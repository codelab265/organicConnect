export default {
  primary: "#70A57B",
  primaryDark: "#86B084",
  secondary: "#E2BB7C",
  blue: "#A0AFD3",
  yellow: "#E4D582",
  black: "#1F2336",
  purple: "#DA88FF",
  white: "#FFFFFF",
  input: "#F2F3F7",
  buttonDisabled: "#EBEAEC",
  gray: "#E5E3DE",
  background: "#E9E8E2",
};
