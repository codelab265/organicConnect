export default {
  title: 24,
  subtitle: 16,
};
